package com.example.FireTCG_Store.controller;



import com.example.FireTCG_Store.model.Carta;
import com.example.FireTCG_Store.service.CartaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/api/v1/cartas")
@RestController
public class CartaController {

    @Autowired
    private CartaService service;

    @PostMapping
    public ResponseEntity<Carta> crear(@RequestBody Carta nuevaCarta){
        Carta carta = service.crear(nuevaCarta);
        return ResponseEntity.ok(carta);
    }


    @GetMapping
    public List<Carta> getCartas(){
        return service.getCartas();
    }

    @GetMapping("/{id}")
    public Optional<Carta> findById(@PathVariable Long id){
        return service.filtrarById(id);
    }

    @GetMapping("/stock/{nombre}")
    public Optional<List<Carta>> findByExpansion(@PathVariable String nombre){
        return service.fitrarByNombre(nombre);
    }

    @GetMapping("/stock/{tcg}")
    public Optional<List<Carta>> findByTcg(@PathVariable String tcg){
        return service.filtrarByTcg(tcg);
    }

}
