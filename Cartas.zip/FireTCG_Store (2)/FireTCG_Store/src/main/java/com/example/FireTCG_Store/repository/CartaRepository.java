package com.example.FireTCG_Store.repository;

import com.example.FireTCG_Store.model.Carta;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CartaRepository extends JpaRepository<Carta,Long> {

    Optional<List<Carta>> findByNombre(String nombre);

    Optional<List<Carta>> findByTcg(String tcg);


}
