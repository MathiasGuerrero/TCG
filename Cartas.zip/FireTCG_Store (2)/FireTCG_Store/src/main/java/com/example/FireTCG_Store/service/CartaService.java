package com.example.FireTCG_Store.service;


import com.example.FireTCG_Store.model.Carta;
import com.example.FireTCG_Store.repository.CartaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class CartaService {

    @Autowired
    private CartaRepository repository;


    public Carta crear(Carta carta){
        return repository.save(carta);
    }

    public List<Carta> getCartas(){
        return repository.findAll();
    }

    public Optional<Carta> filtrarById(Long id){
        return repository.findById(id);
    }

    public Optional<List<Carta>> fitrarByNombre(String nombre){
        return repository.findByNombre(nombre);
    }

    public Optional<List<Carta>> filtrarByTcg(String tcg){
        return repository.findByTcg(tcg);
    }

}
