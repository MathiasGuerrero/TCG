create table Reservas (
id BIGINT PRIMARY KEY AUTO_INCREMENT,
tipo_reserva VARCHAR(50),
producto_reserva VARCHAR(50),
cantidad int(4),
pago int(10)
);