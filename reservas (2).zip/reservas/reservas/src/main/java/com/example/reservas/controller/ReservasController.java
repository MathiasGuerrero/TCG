package com.example.reservas.controller;


import com.example.reservas.model.Reservas;
import com.example.reservas.service.ReservasServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/api/v1/reservas")
@RestController
public class ReservasController {

    @Autowired
    private ReservasServices services;

    @PostMapping
    public ResponseEntity<Reservas> crear(@RequestBody Reservas nuevaReserva) {
        Reservas reservas = services.crear(nuevaReserva);
        return ResponseEntity.ok(reservas);
    }


}