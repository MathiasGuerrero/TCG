package com.example.reservas.repository;


import com.example.reservas.model.Reservas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReservasRepository extends JpaRepository<Reservas,Long> {

    List<Reservas> findByProductoReserva(String producto_reservas);
}
