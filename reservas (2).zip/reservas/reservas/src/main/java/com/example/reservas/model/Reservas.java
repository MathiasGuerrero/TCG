package com.example.reservas.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Reservas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Elija el tipo de reserva")
    @Size(min = 2,max = 50)
    private String tipoReserva;


    @NotBlank(message = "Tiene que elegir un producto")
    @Size(min = 2, max = 50)
    private String productoReserva;

    private int cantidad;

    private int pago;





}
