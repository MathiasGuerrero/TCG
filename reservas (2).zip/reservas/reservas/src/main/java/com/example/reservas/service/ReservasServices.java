package com.example.reservas.service;


import com.example.reservas.model.Reservas;
import com.example.reservas.repository.ReservasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservasServices {

    @Autowired
    private ReservasRepository repository;

    public Reservas crear(Reservas reservas){return repository.save(reservas);}
    public List<Reservas> getReservas(){return repository.findAll();}

    public List<Reservas> fitrarByProducto_reservas(String producto_reservas){
        return repository.findByProductoReserva(producto_reservas);
    }





}
