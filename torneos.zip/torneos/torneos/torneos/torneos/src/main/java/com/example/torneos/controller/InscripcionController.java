package com.example.torneos.controller;

import com.example.torneos.model.Inscripcion;
import com.example.torneos.service.InscripcionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/torneos")
@RequiredArgsConstructor
public class InscripcionController {

    private final InscripcionService service;

    // Inscribir usuario a torneo
    @PostMapping("/{torneoId}/inscribir")
    public ResponseEntity<Inscripcion> inscribir(
            @PathVariable Long torneoId,
            @RequestParam Long usuarioId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.inscribir(torneoId, usuarioId));
    }

    // Ver inscritos de un torneo
    @GetMapping("/{torneoId}/inscritos")
    public ResponseEntity<List<Inscripcion>> getInscritos(@PathVariable Long torneoId) {
        return ResponseEntity.ok(service.getInscritos(torneoId));
    }

    // Desinscribir usuario de un torneo
    @DeleteMapping("/{torneoId}/desinscribir")
    public ResponseEntity<Void> desinscribir(
            @PathVariable Long torneoId,
            @RequestParam Long usuarioId) {
        service.desinscribir(torneoId, usuarioId);
        return ResponseEntity.noContent().build();
    }
}