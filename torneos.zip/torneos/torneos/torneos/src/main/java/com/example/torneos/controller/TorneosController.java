package com.example.torneos.controller;


import com.example.torneos.model.Torneos;
import com.example.torneos.service.TorneoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequestMapping("/api/v1/torneos")
@RestController
public class TorneosController {

    @Autowired
    private TorneoService service;

    @GetMapping
    public List<Torneos> listar(){return service.getTorneos();}

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Torneos>> findById(@PathVariable Long id){
        Optional<Torneos> torneos = service.findById(id);
        return ResponseEntity.ok(torneos);
    }

    @GetMapping("/buscar")
    public ResponseEntity<List<Torneos>> buscarPorParticipantes(@RequestParam int participantes){
        List<Torneos> torneos = service.findByParticipantes(participantes);
        return ResponseEntity.ok(torneos);
    }

    @GetMapping("/nombre/{nombre}")
    public ResponseEntity<Optional<Torneos>> buscarPorNombre(@PathVariable String nombre){
        Optional<Torneos> torneos = service.findByNombre(nombre);
        return ResponseEntity.ok(torneos);
    }

    @GetMapping("/duracion/{duracion}")
    public ResponseEntity<List<Torneos>> buscarPorDuracion(@RequestParam int duracion){
        List<Torneos> torneos = service.findByDuracion(duracion);
        return ResponseEntity.ok(torneos);
    }


    @PostMapping
    public ResponseEntity<Optional<Torneos>> crearTorneo(@RequestBody Torneos torneos){
        Optional<Torneos> torneoCreado = service.crear(torneos);
        return ResponseEntity.ok(torneoCreado);
    }

}
