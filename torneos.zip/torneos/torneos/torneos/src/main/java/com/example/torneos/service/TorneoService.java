package com.example.torneos.service;


import com.example.torneos.model.Torneos;
import com.example.torneos.repository.TorneoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TorneoService {

    @Autowired
    private TorneoRepository repository;

    public Optional<Torneos> crear(Torneos torneos){return Optional.of(repository.save(torneos));}

    public Optional<Torneos> findById(Long id){return repository.findById(id);}

    public Optional<Torneos> findByNombre(String nombre){return repository.findByNombreTorneo(nombre);}

    public List<Torneos> getTorneos(){return repository.findAll();}

    public List<Torneos> findByParticipantes(int participantes){return repository.findByParticipantes(participantes);}

    public List<Torneos> findByDuracion(int duracion){return repository.findByDuracion(duracion);}


}
