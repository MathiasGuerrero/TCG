package com.example.reservas.controller;


import com.example.reservas.model.Reserva;
import com.example.reservas.repository.ReservaRepository;
import com.example.reservas.service.ReservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RequestMapping("/api/v1/reservas")
@RestController
public class ReservaController {


    @Autowired
    private ReservaService service;

    @GetMapping
    public List<Reserva> listar(){return service.getReservas();}

    @GetMapping("/{id}")
    public ResponseEntity<Reserva> findById(@PathVariable Long id){
        Reserva reserva = service.findById(id);
        return ResponseEntity.status(HttpStatus.OK).body(reserva);
    }

    @GetMapping("/tipopago/{tipoPago}")
    public ResponseEntity<List<Reserva>> buscarPorTipoPago(@RequestParam String tipoPago) {
        List<Reserva> reservas = service.findByTipoPago(tipoPago);
        return ResponseEntity.ok(reservas);
    }

    @PostMapping
    public ResponseEntity<Reserva> crearReserva(@RequestBody Reserva reserva){
        Reserva reservaCreada = service.crear(reserva);
        return ResponseEntity.ok(reservaCreada);
    }


}
